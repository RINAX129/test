/**
 * 
 */
/**
 * @author RINAX
 *
 */
package com.internousdev.login.dto;